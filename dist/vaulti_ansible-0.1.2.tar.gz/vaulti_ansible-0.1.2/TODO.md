
Instead of recursing through the entire new folder, maybe just recurse through the original file, replacing whatever values you can still find?
Reduces complixity and a layer of recursion

Maybe use ScalarNode instead of TaggedScalar?
